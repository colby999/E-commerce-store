<!DOCTYPE html>
<html lang="en">
<head>
<title>Contact Form with AJAX jQuery Bootstrap PHP and MySql</title>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="../css/syles.css">
</head>

<body>
    <style>
      #navbar {
        overflow: hidden;
        background-color: #333;
    } 
    #navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 17px;
    }

    #navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    #navbar a.active {
        background-color: #4CAF50;
        color: white;
    }
    
    .jj{
float:left;

    }
   
    </style>
<div id="navbar">

        <a href="../index.html">HOME</a>
        <a href="../store.html">STORE</a>
        <a href="../gallery.html">GALLERY </a>
        <a href="../about.html">ABOUT</a>
        <a href="index.php">CONTACT</a>
        <a href="../login.php">LOGIN </a>
       
    </div>
    <div class="main" id="section1">
    <br>
<div class="container">
 <div class="form-group">
 <label for="email">Email:</label>
 <input id="email" class="form-control" type="email" placeholder="Your Email">
 </div>
 <div class="form-group">
 <label for="subject">Subject:</label>
 <input id="subject" class="form-control" type="text" placeholder="Subject">
 </div>

 <div class="form-group">
 <label for="comments">Your Message:</label>
 <textarea id="comments" class="form-control" placeholder="Enter Text Here"></textarea>
 </div>
 <div class="form-group">
 <label for="spam">Spam Control 5+2=?:</label>
 <input id="spam" class="form-control" type="tel" placeholder="Type 7 here.">
 </div>
<button type="submit" id="submit" class="btn btn-default">Contact</button>
<div id="display"></div></pre>
<h2> Location</h2>
<div class="jj"> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3311.9267041808457!2d18.557559015270538!3d-33.891541480649884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1dcc5bc8f4acc7e3%3A0xc7fff6257116be1e!2sN1%20City%20Mall!5e0!3m2!1sen!2sza!4v1591905240433!5m2!1sen!2sza" width="250" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></div>
<script>
$(document).ready(function(){
$("#submit").click(function(){
var em = $("#email").val();
var sub = $("#subject").val();
var com = $("#comments").val();
var spm = $("#spam").val();
var dataString = 'em1='+ em + '&sub1='+ sub + '&com1='+ com;
if(em==''||sub==''||com=='')
{
$("#display").html("<div class='alert alert-warning'>Please Fill All Fields.</div>");
}
else if(spm!='7')
{
$("#display").html("<div class='alert alert-danger'>Please Answer The Question.</div>");
}
else
{
$.ajax({
type: "POST",
url: "processor.php",
data: dataString,
cache: false,
success: function(result){
$("#display").html(result);
}
});
}
return false;
});
});
</script>
</div>
<a href="#section1">Back to top</a>
</body>
</html>
