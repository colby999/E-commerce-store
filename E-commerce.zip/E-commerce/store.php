<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<html>

<head>
    <title>Crowned Crystals</title>
    <meta name="description" content="This is the description">
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/store.js" async></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<style>
    .header {
        background-color: #f1f1f1;
        padding: 30px;
        text-align: center;
    }

    #navbar {
        overflow: hidden;
        background-color: #333;
    }

    #navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 17px;
    }

    #navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    #navbar a.active {
        background-color: #4CAF50;
        color: white;
    }

    .content {
        padding: 16px;
    }

    .sticky {
        position: fixed;
        top: 0;
        width: 100%;
    }

    .sticky+.content {
        padding-top: 60px;
    }

    @media screen and (max-width: 767px) {
        .sidenav {
            height: auto;
            padding: 0px;
        }

        .row.content {
            height: auto;
        }
    }

    .row.content {
        height: 450px
    }

    /* Set gray background color and 100% height */
    .sidenav {
        padding-top: 0px;
        background-color: none;
        height: 100%;
        float: right;
        width: auto;
        overflow: hidden;
    }

    .modal {
        display: none;
        /* Hidden by default */
        position: fixed;
        /* Stay in place */
        z-index: 1;
        /* Sit on top */
        padding-top: 100px;
        /* Location of the box */
        left: 0;
        top: 0;
        width: 100%;
        /* Full width */
        height: 100%;
        /* Full height */
        overflow: auto;
        /* Enable scroll if needed */
        background-color: rgb(0, 0, 0);
        /* Fallback color */
        background-color: rgba(0, 0, 0, 0.4);
        /* Black w/ opacity */
    }

    /* Modal Content */
    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    /* The Close Button */
    .close {
        color: #aaaaaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
    }
    .fl {
        float: right;

    }
</style>

<body>
    <div id="navbar">
       <li> <a href="index.html">HOME</a>
        <a href="store.html">STORE</a>
        <a href="gallery.html">GALLERY</a>
        <a href="about.html">ABOUT</a>
        <a href="Contact/index.php">CONTACT</a>
        <a href="login.php">PROFILE </a></li>
        <div class="fl">


<!-- Trigger/Open The Modal -->
<button id="myBtn" class="btn btn-info btn-lg">Cart</button>
<span class="glyphicon glyphicon-shopping-cart"></span>
<!-- The Modal -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 class="section-header">CART</h2>

        <div class="cart-row">

            <span class="cart-item cart-header cart-column">ITEM</span>
            <span class="cart-price cart-header cart-column">PRICE</span>
            <span class="cart-quantity cart-header cart-column">QUANTITY</span> </div>

        <div class="cart-items"> </div>
        <div class="cart-total">
            <strong class="cart-total-title">Total</strong>
            <span class="cart-total-price">$0</span> </div>
        <button class="btn btn-primary btn-purchase" type="button">PURCHASE</button>
    </div>

</div>

</div>
</div>
    </div>
    <div class="main" id="section1">
    <div>
        <br> <br>
        <br>
        <br>
       
        


        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to Crowned Crystals.</h1>

       
        <section class="container content-section">
        
            <h2 class="section-header">Pendants</h2>
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Africa Pendant 14k Yellow Gold </span>
                    <img class="shop-item-image" src="images/mj.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">5000.00</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Marijuana Weed Leaf Pendant 14k Yellow Gold</span>
                    <img class="shop-item-image" src="Images/mj2.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">4200.00</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Cat Face Pendant 14k Yellow Gold </span>
                    <img class="shop-item-image" src="Images/mj3.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">5999.99</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Nova Cross Pendant 14k Yellow Gold </span>
                    <img class="shop-item-image" src="Images/mj5.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">4999.99</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>
        <section class="container content-section">
            <h2 class="section-header">Watches</h2>
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title">Audemars Piguet Skeleton 41mm Steel</span>
                    <img class="shop-item-image" src="Images/w2.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">1702059.000</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
                <div class="shop-item">
                    <span class="shop-item-title">Custom Patek Philippe 5980</span>
                    <img class="shop-item-image" src="Images/w3.jpg">
                    <div class="shop-item-details">
                        <span class="shop-item-price">2042470.80</span>
                        <button class="btn btn-primary shop-item-button" type="button">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </section>




        <script>

       



            // Get the modal
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal 
            btn.onclick = function () {
                modal.style.display = "block";
            }

            // When the user clicks on <span> (x), close the modal
            span.onclick = function () {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function (event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        </script>
        <a href="#section1">Back to top</a>
        <footer class="container-fluid text-center">
            <p>Crowned Crystals</p>
        </footer>
        

</body>

</html>